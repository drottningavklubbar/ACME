import logging  
logger = logging.getLogger()
logger.setLevel(logging.INFO)
# set it as DEBUG 
import psycopg2 as pg
import json

def connection_db():
    try:
        connection = pg.connect(
                        dbname = "acme", 
                        user = "oanacazan",
                        password = "NewDb1234#",
                        host = "localhost",
                        port = "5432"
        )
        return connection
    except ConnectionError as error:
        logger.error(error)
        print(error)

def read_json_file(path: str):
    with open(path, 'r') as file:
        return json.load(file)

def read_file(path: str):
    with open(path, 'r') as file:
        return file.read()
      
connection = connection_db()
cursor = connection.cursor()
create_table = read_file('create_table.sql')
cursor.execute(create_table)
connection.commit()
# result = cursor.fetchall()
# print(result)
# Close connection
cursor.close()
connection.close()
file_content = read_file(path="iamExample.json")
# print(file_content)