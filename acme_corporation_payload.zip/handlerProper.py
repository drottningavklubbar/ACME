import logging  
import psycopg2 as pg
import json
import boto3
# According with [https://docs.aws.amazon.com/code-library/latest/ug/lambda_example_serverless_S3_Lambda_section.html]

# set it as DEBUG 
logger = logging.getLogger()
logger.setLevel(logging.INFO)

client = boto3.client('s3')

def connection_db():
    try:
        # TODO - encrypt on the user and password or to save them in Parameter Storage
        connection = pg.connect(
                        dbname = "acme", 
                        user = "oanacazan",
                        password = "NewDb1234#",
                        host = "localhost",
                        port = "5432"
        )
        return connection
    except ConnectionError as error:
        logger.error(error)

def get_object(bucket: str, key: str):
    response = client.get_object(Bucket = bucket, Key=key)
    file_content = response['Body'].read().decode('utf-8')
    return json.loads(file_content)

def read_file(path: str):
    with open(path, 'r') as file:
        return file.read()

def lambda_handler(event, context):
    bucket = event['Records'][0]['s3']['bucket']['name']
    # TODO - the naming of the file according with CloudTrail
    key = event['Records'][0]['s3']['object']['key']
    data = get_object(bucket, key)
    logger.info("The response is generated -> %s", str(data))
    client.close()